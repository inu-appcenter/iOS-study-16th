import SwiftSoup
import Foundation


struct Info {
    var title: String
    var link: String
    var preview: String
}

let keywordSearchInNaver: KeywordSearchInNaver = KeywordSearchInNaver()

class Naver {

    // Naver 에서 keyword를 검색했을 때 나오는 글들의 정보를 출력
    func Search(_ keyword: String) -> [Info] {
        var InfoArray:[Info] = []
        let url = URL(string: "https://search.naver.com/search.naver?display=15&f=&filetype=0&page=2&query=" + keyword + "&research_url=&sm=tab_pge&start=1&where=web")
        let myURL = url
        if let myURL = myURL {
            do {
                
                let html = try String(contentsOf: myURL, encoding: .utf8) //url주소로 해당 웹 페이지를 문자열형태(html)코드로 가져오기
                let doc: Document = try SwiftSoup.parse(html) //html코드를 parsing해서 tree구조로 반환
                //select 메소드를 통해 원하는 데이터 추출 및 하위요소들 다루기
                let hls: Elements = try doc.select(".hl").select("strong")
                let alinks: Elements = try doc.select(".link_tit").select("a")
                let preview_texts : Elements = try doc.select(".total_dsc").select("a")
                
                for idx in 0..<min(hls.count, alinks.count) {
                    let information: Info = Info(title: try hls[idx].text(), link: try alinks[idx].attr("href"), preview: try preview_texts[idx].text())
                    InfoArray.append(information)
                }
                return InfoArray
                
            } catch Exception.Error(type: let type, Message: let message) {
                print(type)
                print(message)
                return [Info(title: "", link: "", preview: "")]
            } catch{
                print("")
                return [Info(title: "", link: "", preview: "")]
            }
        }
        return [Info(title: "", link: "", preview: "")]
    }
}

class KeywordSearchInNaver {
    let naver: Naver = Naver()

    func loop() {
        while(true) {
            print("\n\n")
            print("검색어 입력: ", terminator: "")
            let keyword: String? = readLine()
            if let tmp = keyword {
                let results: [Info] = naver.Search(tmp)
                self.printResult(results)
                if keyword == "0" {
                    break
                }
            }
        }
    }
    
    func printResult(_ results: [Info]) {
//        guard let results = results else {
//            print("검색 결과가 없습니다.")
//            return
//        }
//
        for (idx, ret) in results.enumerated() {
            print("title: \(ret.title)\n")
            print("link: \(ret.link)\n")
            print("preview: \(ret.preview)\n")
        }
        print("==================================\n")
    }
}

keywordSearchInNaver.loop()
